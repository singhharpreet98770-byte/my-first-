/**
 * API Service Layer for communicating with Express Backend
 */

const API_BASE_URL = 'http://localhost:5000/api';

// Fallback items in case backend is loading or offline
const FALLBACK_FOODS = [
  {
    _id: "demo-1",
    name: "Hyderabadi Dum Chicken Biryani",
    description: "Aromatic long-grain basmati rice layered with spiced marinated chicken, saffron, brown onions, and royal herbs. Served with Mirchi ka Salan & Raita.",
    price: 349,
    category: "Biryani",
    rating: 4.9,
    isVeg: false,
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-2",
    name: "Royal Paneer Butter Masala",
    description: "Fresh cottage cheese cubes simmered in a velvety, rich tomato cashew gravy with real butter and aromatic kasturi methi.",
    price: 289,
    category: "North Indian",
    rating: 4.8,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-3",
    name: "Classic Murgh Makhani (Butter Chicken)",
    description: "Tender tandoori chicken cooked in slow-simmered silky tomato-butter gravy with fenugreek and a touch of organic honey.",
    price: 379,
    category: "North Indian",
    rating: 4.9,
    isVeg: false,
    image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-4",
    name: "Mysore Masala Dosa",
    description: "Golden crispy fermented crepe smeared with spicy red chutney and stuffed with seasoned potato masala. Served with hot Sambar and 2 chutneys.",
    price: 179,
    category: "South Indian",
    rating: 4.7,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-5",
    name: "Amritsari Chole Bhature Special",
    description: "Spicy and tangy Punjabi pindi chole cooked with dark tea-leaf brew, served with 2 jumbo fluffy bhature, pickled chillies, and onions.",
    price: 199,
    category: "North Indian",
    rating: 4.8,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-6",
    name: "Dilli 6 Samosa Chaat",
    description: "Crispy fried potato samosas broken and smothered with chole, chilled sweet curd, tangy tamarind saunth chutney, mint chutney, and nylon sev.",
    price: 139,
    category: "Street Food",
    rating: 4.6,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-7",
    name: "Tandoori Paneer Tikka Desi Pizza",
    description: "Crispy handcrafted thin crust topped with spicy chargrilled paneer cubes, crunchy capsicum, red onions, mozzarella, and makhani drizzle.",
    price: 329,
    category: "Pizza",
    rating: 4.7,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-8",
    name: "Chicken Tikka Makhani Pizza",
    description: "Loaded with smoky tandoori chicken tikka, rich makhani sauce, mozzarella cheese, and fresh coriander on a golden crust.",
    price: 389,
    category: "Pizza",
    rating: 4.8,
    isVeg: false,
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-9",
    name: "Crispy Desi Aloo Tikki Burger",
    description: "Golden spiced potato and pea patty with crunchy lettuce, onions, juicy tomatoes, and mint-mayo dressing inside toasted buns.",
    price: 129,
    category: "Burger",
    rating: 4.5,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-10",
    name: "Hot Shahi Gulab Jamun with Rabri (2 Pcs)",
    description: "Soft melt-in-mouth mawa dumplings soaked in green cardamom rose sugar syrup, served with creamy thickened rabri and dry fruit slivers.",
    price: 159,
    category: "Dessert",
    rating: 4.9,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-11",
    name: "Kesari Mango Lassi",
    description: "Rich, thick, slow-churned yogurt smoothie blended with sweet Ratnagiri Alphonso mango pulp and topped with saffron strands.",
    price: 119,
    category: "Drinks",
    rating: 4.8,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80"
  },
  {
    _id: "demo-12",
    name: "Special Punjabi Veg Thali Deluxe",
    description: "Complete feast with Paneer Butter Masala, Dal Makhani, Mixed Veg, Jeera Rice, 2 Butter Naans, Raita, Salad & 1 Gulab Jamun.",
    price: 399,
    category: "North Indian",
    rating: 4.9,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80"
  }
];

// Helper to get auth header
const getAuthHeaders = () => {
  const token = localStorage.getItem('cravebite_token');
  const headers = { 'Content-Type': 'application/json' };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

export const authApi = {
  // Login user
  async login(credentials) {
    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || 'Login failed');
    }
    return data;
  },

  // Register user
  async register(userData) {
    const res = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || 'Registration failed');
    }
    return data;
  },

  // Get current user profile
  async getProfile() {
    const res = await fetch(`${API_BASE_URL}/auth/profile`, {
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || 'Failed to fetch user profile');
    }
    return data.user;
  }
};

export const foodApi = {
  // Fetch all foods with optional filtering
  async getAllFoods(category = '', search = '') {
    try {
      const params = new URLSearchParams();
      if (category && category !== 'All') params.append('category', category);
      if (search) params.append('search', search);

      const url = `${API_BASE_URL}/foods${params.toString() ? `?${params.toString()}` : ''}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);
      const data = await res.json();
      return data.data || [];
    } catch (err) {
      console.warn('Backend not responding, displaying fallback foods:', err.message);
      let filtered = [...FALLBACK_FOODS];
      if (category && category !== 'All') {
        filtered = filtered.filter(f => f.category.toLowerCase() === category.toLowerCase());
      }
      if (search) {
        filtered = filtered.filter(f => 
          f.name.toLowerCase().includes(search.toLowerCase()) || 
          f.description.toLowerCase().includes(search.toLowerCase())
        );
      }
      return filtered;
    }
  },

  // Place a new food order
  async placeOrder(orderPayload) {
    try {
      const res = await fetch(`${API_BASE_URL}/orders`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(orderPayload)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to place order');
      return data;
    } catch (err) {
      console.warn('Backend unavailable, using local mock order placement:', err.message);
      // Generate a mock order for standalone demonstration
      const mockOrder = {
        success: true,
        message: 'Order placed successfully! (Offline Mode)',
        data: {
          _id: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
          customer: orderPayload.customer,
          items: orderPayload.items,
          totalAmount: orderPayload.totalAmount,
          paymentMethod: orderPayload.paymentMethod,
          status: 'Order Placed',
          createdAt: new Date().toISOString()
        }
      };
      // Store in localStorage for MyOrders offline support
      const existing = JSON.parse(localStorage.getItem('cravebite_local_orders') || '[]');
      existing.unshift(mockOrder.data);
      localStorage.setItem('cravebite_local_orders', JSON.stringify(existing));
      return mockOrder;
    }
  },

  // Fetch all orders
  async getOrders() {
    try {
      const res = await fetch(`${API_BASE_URL}/orders`, {
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);
      const data = await res.json();
      return data.data || [];
    } catch (err) {
      console.warn('Backend unavailable, reading local saved orders:', err.message);
      return JSON.parse(localStorage.getItem('cravebite_local_orders') || '[]');
    }
  }
};

export const adminApi = {
  // Get dashboard statistics
  async getStats() {
    const res = await fetch(`${API_BASE_URL}/admin/stats`, {
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to fetch admin stats');
    return data;
  },

  // Get all orders with optional filter
  async getAllOrders(status = '', search = '') {
    const params = new URLSearchParams();
    if (status && status !== 'All') params.append('status', status);
    if (search) params.append('search', search);

    const url = `${API_BASE_URL}/admin/orders${params.toString() ? `?${params.toString()}` : ''}`;
    const res = await fetch(url, { headers: getAuthHeaders() });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to fetch orders');
    return data.data || [];
  },

  // Update order status
  async updateOrderStatus(orderId, status) {
    const res = await fetch(`${API_BASE_URL}/orders/${orderId}/status`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ status })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to update order status');
    return data;
  },

  // Delete an order
  async deleteOrder(orderId) {
    const res = await fetch(`${API_BASE_URL}/admin/orders/${orderId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to delete order');
    return data;
  },

  // Add a new food item
  async createFood(foodData) {
    const res = await fetch(`${API_BASE_URL}/foods`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(foodData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to create food item');
    return data;
  },

  // Update an existing food item
  async updateFood(foodId, foodData) {
    const res = await fetch(`${API_BASE_URL}/foods/${foodId}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(foodData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to update food item');
    return data;
  },

  // Delete a food item
  async deleteFood(foodId) {
    const res = await fetch(`${API_BASE_URL}/foods/${foodId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to delete food item');
    return data;
  },

  // Get all registered users
  async getUsers() {
    const res = await fetch(`${API_BASE_URL}/admin/users`, {
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to fetch users');
    return data.data || [];
  },

  // Update a user role
  async updateUserRole(userId, role) {
    const res = await fetch(`${API_BASE_URL}/admin/users/${userId}/role`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ role })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to update user role');
    return data;
  }
};

