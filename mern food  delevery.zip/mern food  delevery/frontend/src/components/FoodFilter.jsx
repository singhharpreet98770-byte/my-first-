import React from 'react';

const categories = [
  { name: 'All', icon: '🍽️' },
  { name: 'Biryani', icon: '🍗' },
  { name: 'North Indian', icon: '🍛' },
  { name: 'South Indian', icon: '🥞' },
  { name: 'Street Food', icon: '🥟' },
  { name: 'Pizza', icon: '🍕' },
  { name: 'Burger', icon: '🍔' },
  { name: 'Dessert', icon: '🍨' },
  { name: 'Drinks', icon: '🥤' }
];

const FoodFilter = ({ selectedCategory, onSelectCategory }) => {
  return (
    <div className="filter-section">
      <div className="section-header">
        <h2 className="section-title">Explore India's Favorite Flavors</h2>
      </div>

      <div className="category-list">
        {categories.map((cat) => (
          <button
            key={cat.name}
            className={`category-pill ${selectedCategory === cat.name ? 'active' : ''}`}
            onClick={() => onSelectCategory(cat.name)}
          >
            <span className="category-icon">{cat.icon}</span>
            <span>{cat.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default FoodFilter;
