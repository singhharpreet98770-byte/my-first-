import React from 'react';
import { useCart } from '../context/CartContext';

const FoodCard = ({ food }) => {
  const { addToCart, updateQuantity, getItemQuantity } = useCart();
  const foodId = food._id || food.id;
  const quantity = getItemQuantity(foodId);

  return (
    <div className="food-card">
      {/* Image & Badges */}
      <div className="food-card-img-wrapper">
        <img
          src={food.image}
          alt={food.name}
          className="food-card-img"
          loading="lazy"
        />
        <span className={`veg-badge ${food.isVeg ? 'veg' : 'non-veg'}`}>
          {food.isVeg ? '🟢 Veg' : '🔴 Non-Veg'}
        </span>
        <span className="rating-badge">
          ⭐ {food.rating || 4.5}
        </span>
      </div>

      {/* Body Content */}
      <div className="food-card-body">
        <span className="food-category">{food.category}</span>
        <h3 className="food-title">{food.name}</h3>
        <p className="food-description">{food.description}</p>

        {/* Footer with Price and Cart Action */}
        <div className="food-card-footer">
          <span className="food-price">₹{Number(food.price)}</span>

          {quantity === 0 ? (
            <button
              className="add-to-cart-btn"
              onClick={() => addToCart(food)}
              aria-label={`Add ${food.name} to cart`}
            >
              <span>+ Add</span>
            </button>
          ) : (
            <div className="qty-controls">
              <button
                className="qty-btn"
                onClick={() => updateQuantity(foodId, -1)}
                aria-label="Decrease quantity"
              >
                -
              </button>
              <span className="qty-count">{quantity}</span>
              <button
                className="qty-btn"
                onClick={() => updateQuantity(foodId, 1)}
                aria-label="Increase quantity"
              >
                +
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FoodCard;
