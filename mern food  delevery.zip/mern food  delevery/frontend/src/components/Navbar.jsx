import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { cartCount } = useCart();
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();

  return (
    <header className="navbar">
      <div className="container nav-container">
        {/* Brand Logo */}
        <Link to="/" className="logo">
          <span className="logo-icon">🍕</span>
          <span>Crave</span>Bite
        </Link>

        {/* Navigation Links */}
        <nav>
          <ul className="nav-links">
            <li>
              <Link
                to="/"
                className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
              >
                🍽️ Menu
              </Link>
            </li>
            <li>
              <Link
                to="/my-orders"
                className={`nav-link ${location.pathname === '/my-orders' ? 'active' : ''}`}
              >
                📦 My Orders
              </Link>
            </li>
            <li>
              <Link
                to="/admin"
                className={`nav-link ${location.pathname === '/admin' ? 'active' : ''}`}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '5px',
                  fontWeight: 800,
                  ...(user?.role === 'admin'
                    ? {
                        background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
                        color: '#fbbf24',
                        border: '1px solid #d97706',
                        padding: '6px 14px',
                        borderRadius: 'var(--radius-full)'
                      }
                    : {
                        color: location.pathname === '/admin' ? 'var(--primary)' : 'var(--text-main)'
                      })
                }}
              >
                {user?.role === 'admin' ? '⭐ Admin Panel' : '⚡ Admin'}
              </Link>
            </li>

            {/* Auth Buttons / User Profile */}
            {isAuthenticated ? (
              <li style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '6px 12px',
                    borderRadius: 'var(--radius-full)',
                    background: user?.role === 'admin' ? '#eff6ff' : 'var(--primary-light)',
                    color: user?.role === 'admin' ? '#2563eb' : 'var(--primary)',
                    fontWeight: 700,
                    fontSize: '0.88rem',
                    border: user?.role === 'admin' ? '1px solid #bfdbfe' : 'none'
                  }}
                  title={user?.email}
                >
                  👤 {user?.name?.split(' ')[0] || 'User'} {user?.role === 'admin' && '(Admin)'}
                </span>
                <button
                  onClick={logout}
                  style={{
                    background: 'transparent',
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius-sm)',
                    padding: '6px 12px',
                    fontSize: '0.85rem',
                    fontWeight: 600,
                    color: 'var(--text-muted)',
                    cursor: 'pointer',
                    transition: 'var(--transition)'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.color = 'var(--danger)';
                    e.currentTarget.style.borderColor = 'var(--danger)';
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.color = 'var(--text-muted)';
                    e.currentTarget.style.borderColor = 'var(--border)';
                  }}
                >
                  Logout
                </button>
              </li>
            ) : (
              <li>
                <Link
                  to="/login"
                  className={`nav-link ${location.pathname === '/login' ? 'active' : ''}`}
                >
                  🔑 Login
                </Link>
              </li>
            )}

            <li>
              <Link to="/cart" className="cart-btn">
                <span>🛒 Cart</span>
                {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
