import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-brand">
            <h3><span>Crave</span>Bite India 🇮🇳</h3>
            <p>
              Delivering hot, authentic Indian meals, Biryanis, Street Food & Desserts across major cities in India.
              Crafted with clean code using the MERN Stack.
            </p>
          </div>

          <div>
            <h4 className="footer-title">Top Cities Served</h4>
            <ul className="footer-links">
              <li>📍 Delhi NCR & Gurgaon</li>
              <li>📍 Mumbai & Pune</li>
              <li>📍 Bengaluru & Hyderabad</li>
              <li>📍 Chandigarh & Kolkata</li>
            </ul>
          </div>

          <div>
            <h4 className="footer-title">Quick Links</h4>
            <ul className="footer-links">
              <li><Link to="/">🍽️ Indian Menu</Link></li>
              <li><Link to="/cart">🛒 Shopping Cart</Link></li>
              <li><Link to="/my-orders">📦 My Orders</Link></li>
              <li><Link to="/login">🔑 Account Login</Link></li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>© {new Date().getFullYear()} CraveBite India. Made with ❤️ in India. Built with MERN Stack (All Prices in INR ₹).</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
