import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }) => {
  // Load initial cart state from localStorage
  const [cartItems, setCartItems] = useState(() => {
    try {
      const savedCart = localStorage.getItem('cravebite_cart');
      return savedCart ? JSON.parse(savedCart) : [];
    } catch (e) {
      console.error('Failed to parse cart from localStorage', e);
      return [];
    }
  });

  // Keep localStorage in sync with cart state
  useEffect(() => {
    try {
      localStorage.setItem('cravebite_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cartItems]);

  // Add item to cart or increment quantity if already present
  const addToCart = (foodItem) => {
    setCartItems((prevItems) => {
      const itemId = foodItem._id || foodItem.id;
      const existingItemIndex = prevItems.findIndex(
        (item) => (item._id || item.id) === itemId
      );

      if (existingItemIndex > -1) {
        // Item exists, increment quantity
        const updated = [...prevItems];
        updated[existingItemIndex] = {
          ...updated[existingItemIndex],
          quantity: updated[existingItemIndex].quantity + 1
        };
        return updated;
      } else {
        // Add new item with quantity 1
        return [...prevItems, { ...foodItem, quantity: 1 }];
      }
    });
  };

  // Update item quantity directly or by delta (+1 / -1)
  const updateQuantity = (foodId, delta) => {
    setCartItems((prevItems) => {
      return prevItems
        .map((item) => {
          const currentId = item._id || item.id;
          if (currentId === foodId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean); // Remove items with quantity 0
    });
  };

  // Remove item completely from cart
  const removeFromCart = (foodId) => {
    setCartItems((prevItems) =>
      prevItems.filter((item) => (item._id || item.id) !== foodId)
    );
  };

  // Clear all items in cart (after successful order)
  const clearCart = () => {
    setCartItems([]);
  };

  // Check quantity of specific item in cart
  const getItemQuantity = (foodId) => {
    const item = cartItems.find((i) => (i._id || i.id) === foodId);
    return item ? item.quantity : 0;
  };

  // Calculate total price of cart
  const cartTotal = cartItems.reduce(
    (sum, item) => sum + Number(item.price) * item.quantity,
    0
  );

  // Calculate total number of individual items
  const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        getItemQuantity,
        cartTotal,
        cartCount
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
