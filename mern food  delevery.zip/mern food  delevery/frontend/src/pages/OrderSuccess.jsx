import React from 'react';
import { useLocation, Link } from 'react-router-dom';

const OrderSuccess = () => {
  const location = useLocation();
  const order = location.state?.order;

  return (
    <div className="container main-content">
      <div className="order-success-card">
        <div className="success-icon-bubble">✓</div>
        <h1 style={{ fontFamily: 'var(--font-heading)', color: 'var(--secondary)', marginBottom: '8px' }}>
          Woohoo! Order Confirmed!
        </h1>
        <p style={{ color: 'var(--text-muted)' }}>
          Your food is being prepared with love and will be delivered shortly.
        </p>

        {order && (
          <>
            <div className="order-id-badge">
              Order ID: #{order._id || 'ORD-982312'}
            </div>

            <div style={{
              background: '#f8fafc',
              borderRadius: 'var(--radius-md)',
              padding: '20px',
              textAlign: 'left',
              margin: '20px 0',
              border: '1px solid var(--border)'
            }}>
              <h4 style={{ color: 'var(--secondary)', marginBottom: '10px' }}>Delivery Details:</h4>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginBottom: '4px' }}>
                👤 <strong>Customer:</strong> {order.customer?.name} ({order.customer?.phone})
              </p>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginBottom: '4px' }}>
                🏠 <strong>Address:</strong> {order.customer?.address}, {order.customer?.city}
              </p>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginBottom: '4px' }}>
                💳 <strong>Payment:</strong> {order.paymentMethod}
              </p>
              <p style={{ fontSize: '0.95rem', color: 'var(--primary)', fontWeight: 700, marginTop: '8px' }}>
                💰 Total Paid: ₹{Number(order.totalAmount || 0)}
              </p>
            </div>
          </>
        )}

        <div style={{ display: 'flex', gap: '16px', justifyContent: 'center', marginTop: '24px' }}>
          <Link to="/my-orders" className="cart-btn" style={{ background: '#334155' }}>
            📦 View My Orders
          </Link>
          <Link to="/" className="cart-btn">
            🍕 Order More Food
          </Link>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;
