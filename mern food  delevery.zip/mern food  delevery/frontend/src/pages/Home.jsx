import React, { useState, useEffect } from 'react';
import FoodCard from '../components/FoodCard';
import FoodFilter from '../components/FoodFilter';
import { foodApi } from '../services/api';

const Home = () => {
  const [foods, setFoods] = useState([]);
  const [category, setCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchFoods = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await foodApi.getAllFoods(category, searchQuery);
      setFoods(data);
    } catch (err) {
      console.error(err);
      setError('Could not load food items. Please check if the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch foods whenever category changes
  useEffect(() => {
    fetchFoods();
  }, [category]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchFoods();
  };

  return (
    <div className="container main-content">
      {/* Hero Banner */}
      <section className="hero">
        <div className="hero-text">
          <span className="hero-tag">🇮🇳 ⚡ Express 30-Min Delivery in India</span>
          <h1 className="hero-title">
            Craving Authentic Food? <br />
            <span>Delivered Fresh & Hot.</span>
          </h1>
          <p className="hero-desc">
            Explore authentic Hyderabadi Dum Biryanis, buttery North Indian gravies, crispy South Indian Dosas, and iconic Indian Street Food from top local kitchens.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearchSubmit} className="hero-search-box">
            <input
              type="text"
              placeholder="Search Biryani, Butter Chicken, Dosa, Paneer, Chaat..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="hero-search-input"
            />
            <button type="submit" className="hero-search-btn">
              Search
            </button>
          </form>
        </div>

        <div className="hero-banner-art">
          <span>🍗</span>
          <span>🍛</span>
        </div>
      </section>

      {/* Category Filter */}
      <FoodFilter
        selectedCategory={category}
        onSelectCategory={(cat) => setCategory(cat)}
      />

      {/* Food Items Section */}
      {loading ? (
        <div className="spinner" />
      ) : error ? (
        <div className="empty-state">
          <p style={{ color: 'var(--danger)', fontWeight: 600 }}>{error}</p>
        </div>
      ) : foods.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">🍽️</div>
          <h3>No food items found</h3>
          <p style={{ color: 'var(--text-muted)' }}>
            Try searching for something else like "Biryani", "Paneer", or "Dosa"!
          </p>
        </div>
      ) : (
        <div className="food-grid">
          {foods.map((food) => (
            <FoodCard key={food._id || food.id} food={food} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;
