import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { foodApi } from '../services/api';

const Checkout = () => {
  const { cartItems, cartTotal, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  // Indian pricing: Free delivery above ₹299, otherwise ₹40 delivery fee
  const deliveryFee = cartTotal >= 299 ? 0 : 40;
  // 5% GST
  const tax = cartTotal > 0 ? Math.round(cartTotal * 0.05) : 0;
  const grandTotal = cartTotal + deliveryFee + tax;

  // Form State
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
    city: user?.city || 'New Delhi',
    pincode: user?.pincode || '110001',
    paymentMethod: 'UPI (GPay / PhonePe / Paytm)'
  });

  // Keep form data synced if user logs in
  useEffect(() => {
    if (user) {
      setFormData((prev) => ({
        ...prev,
        name: prev.name || user.name || '',
        email: prev.email || user.email || '',
        phone: prev.phone || user.phone || '',
        address: prev.address || user.address || '',
        city: prev.city || user.city || 'New Delhi',
        pincode: prev.pincode || user.pincode || '110001'
      }));
    }
  }, [user]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (cartItems.length === 0) {
    return (
      <div className="container main-content">
        <div className="empty-state">
          <div className="empty-state-icon">🛍️</div>
          <h2>No items to checkout</h2>
          <p style={{ color: 'var(--text-muted)', margin: '10px 0 20px 0' }}>
            Please add items to your cart before proceeding to checkout.
          </p>
          <Link to="/" className="cart-btn" style={{ display: 'inline-flex' }}>
            Browse Indian Menu
          </Link>
        </div>
      </div>
    );
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePaymentSelect = (method) => {
    setFormData((prev) => ({ ...prev, paymentMethod: method }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Form validation
    if (!formData.name || !formData.email || !formData.phone || !formData.address) {
      setError('Please fill in all the required delivery fields.');
      return;
    }

    try {
      setLoading(true);

      const orderPayload = {
        customer: {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          address: formData.address,
          city: formData.city,
          pincode: formData.pincode
        },
        items: cartItems,
        totalAmount: grandTotal,
        paymentMethod: formData.paymentMethod
      };

      const result = await foodApi.placeOrder(orderPayload);

      if (result.success || result.data) {
        // Clear cart in state and local storage
        clearCart();
        // Redirect to order success page with order details
        navigate('/order-success', { state: { order: result.data || result } });
      } else {
        throw new Error(result.message || 'Failed to place order');
      }
    } catch (err) {
      console.error(err);
      setError(err.message || 'Something went wrong while placing your order.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container main-content">
      <h1 className="section-title" style={{ marginTop: '28px' }}>
        🚀 Delivery Details & Checkout
      </h1>

      {error && (
        <div style={{
          background: '#fee2e2',
          color: '#991b1b',
          padding: '12px 18px',
          borderRadius: 'var(--radius-sm)',
          marginTop: '16px',
          fontWeight: 600
        }}>
          ⚠️ {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="checkout-grid">
        {/* Delivery Information Form */}
        <div className="cart-items-card">
          <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '20px' }}>
            📍 Delivery Address (India)
          </h3>

          <div className="form-group">
            <label className="form-label">Full Name *</label>
            <input
              type="text"
              name="name"
              required
              placeholder="e.g. Harpreet Singh"
              value={formData.name}
              onChange={handleInputChange}
              className="form-input"
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Email Address *</label>
              <input
                type="email"
                name="email"
                required
                placeholder="harpreet@example.com"
                value={formData.email}
                onChange={handleInputChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Mobile Number *</label>
              <input
                type="tel"
                name="phone"
                required
                placeholder="+91 98765 43210"
                value={formData.phone}
                onChange={handleInputChange}
                className="form-input"
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Flat, House No., Building, Street *</label>
            <input
              type="text"
              name="address"
              required
              placeholder="e.g. Flat 302, Royal Palms, Connaught Place"
              value={formData.address}
              onChange={handleInputChange}
              className="form-input"
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">City / Town</label>
              <input
                type="text"
                name="city"
                placeholder="e.g. New Delhi"
                value={formData.city}
                onChange={handleInputChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Pincode (6-digit)</label>
              <input
                type="text"
                name="pincode"
                placeholder="e.g. 110001"
                maxLength={6}
                value={formData.pincode}
                onChange={handleInputChange}
                className="form-input"
              />
            </div>
          </div>

          {/* Payment Method Selection */}
          <h3 style={{ fontFamily: 'var(--font-heading)', margin: '24px 0 12px 0' }}>
            💳 Payment Method
          </h3>

          <div className="payment-methods">
            <div
              className={`payment-option ${formData.paymentMethod === 'UPI (GPay / PhonePe / Paytm)' ? 'active' : ''}`}
              onClick={() => handlePaymentSelect('UPI (GPay / PhonePe / Paytm)')}
            >
              <span>📱</span>
              <span>UPI (GPay / PhonePe / Paytm)</span>
            </div>

            <div
              className={`payment-option ${formData.paymentMethod === 'Credit / Debit Card (RuPay / Visa / MC)' ? 'active' : ''}`}
              onClick={() => handlePaymentSelect('Credit / Debit Card (RuPay / Visa / MC)')}
            >
              <span>💳</span>
              <span>Cards (RuPay / Visa / Mastercard)</span>
            </div>

            <div
              className={`payment-option ${formData.paymentMethod === 'Cash on Delivery (COD)' ? 'active' : ''}`}
              onClick={() => handlePaymentSelect('Cash on Delivery (COD)')}
            >
              <span>💵</span>
              <span>Cash on Delivery (COD)</span>
            </div>

            <div
              className={`payment-option ${formData.paymentMethod === 'Net Banking' ? 'active' : ''}`}
              onClick={() => handlePaymentSelect('Net Banking')}
            >
              <span>🏦</span>
              <span>Indian Net Banking</span>
            </div>
          </div>
        </div>

        {/* Order Review & Submit */}
        <div className="cart-summary-card">
          <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '18px' }}>
            Bill Details ({cartItems.length} items)
          </h3>

          <div style={{ maxHeight: '200px', overflowY: 'auto', marginBottom: '16px' }}>
            {cartItems.map((item) => (
              <div key={item._id || item.id} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px', fontSize: '0.88rem' }}>
                <span>{item.name} × {item.quantity}</span>
                <span style={{ fontWeight: 600 }}>
                  ₹{Number(item.price) * item.quantity}
                </span>
              </div>
            ))}
          </div>

          <div className="summary-row">
            <span>Item Total</span>
            <span>₹{cartTotal}</span>
          </div>

          <div className="summary-row">
            <span>Delivery Fee</span>
            <span>{deliveryFee === 0 ? <strong style={{ color: 'var(--success)' }}>FREE</strong> : `₹${deliveryFee}`}</span>
          </div>

          <div className="summary-row">
            <span>GST & Charges (5%)</span>
            <span>₹{tax}</span>
          </div>

          <div className="summary-row total">
            <span>Total Payable</span>
            <span>₹{grandTotal}</span>
          </div>

          <button
            type="submit"
            className="checkout-btn"
            disabled={loading}
            style={{ opacity: loading ? 0.7 : 1 }}
          >
            {loading ? 'Placing Order...' : '🎉 Pay & Place Order'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default Checkout;
