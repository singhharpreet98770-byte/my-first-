import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const Cart = () => {
  const { cartItems, updateQuantity, removeFromCart, clearCart, cartTotal } = useCart();
  const navigate = useNavigate();

  // Indian pricing: Free delivery above ₹299, otherwise ₹40 delivery fee
  const deliveryFee = cartTotal >= 299 ? 0 : 40;
  // 5% GST on food orders
  const tax = cartTotal > 0 ? Math.round(cartTotal * 0.05) : 0;
  const grandTotal = cartTotal + deliveryFee + tax;

  if (cartItems.length === 0) {
    return (
      <div className="container main-content">
        <div className="empty-state">
          <div className="empty-state-icon">🛒</div>
          <h2>Your Food Cart is Empty</h2>
          <p style={{ color: 'var(--text-muted)', margin: '10px 0 24px 0' }}>
            Looks like you haven't added anything to your cart yet. Explore our authentic Indian menu!
          </p>
          <Link to="/" className="cart-btn" style={{ display: 'inline-flex' }}>
            🍽️ Browse Indian Menu
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container main-content">
      <h1 className="section-title" style={{ marginTop: '28px' }}>
        🛒 Your Food Cart ({cartItems.length} {cartItems.length === 1 ? 'item' : 'items'})
      </h1>

      <div className="cart-layout">
        {/* Cart Items List */}
        <div className="cart-items-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h3 style={{ fontFamily: 'var(--font-heading)' }}>Order Items</h3>
            <button
              onClick={clearCart}
              style={{ color: 'var(--danger)', fontSize: '0.85rem', fontWeight: 600 }}
            >
              Clear Cart
            </button>
          </div>

          {cartItems.map((item) => {
            const itemId = item._id || item.id;
            const subtotal = Number(item.price) * item.quantity;

            return (
              <div key={itemId} className="cart-item">
                <div className="cart-item-info">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="cart-item-img"
                  />
                  <div>
                    <h4 className="cart-item-title">{item.name}</h4>
                    <span className="cart-item-price">
                      ₹{Number(item.price)} each
                    </span>
                  </div>
                </div>

                <div className="cart-item-actions">
                  <div className="qty-controls">
                    <button
                      className="qty-btn"
                      onClick={() => updateQuantity(itemId, -1)}
                      aria-label="Decrease quantity"
                    >
                      -
                    </button>
                    <span className="qty-count">{item.quantity}</span>
                    <button
                      className="qty-btn"
                      onClick={() => updateQuantity(itemId, 1)}
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>

                  <div className="cart-item-subtotal">
                    ₹{subtotal}
                  </div>

                  <button
                    className="delete-btn"
                    onClick={() => removeFromCart(itemId)}
                    title="Remove item"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Order Summary Card */}
        <div className="cart-summary-card">
          <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '18px' }}>
            Bill Details
          </h3>

          <div className="summary-row">
            <span>Item Total</span>
            <span>₹{cartTotal}</span>
          </div>

          <div className="summary-row">
            <span>Delivery Partner Fee</span>
            <span>
              {deliveryFee === 0 ? (
                <strong style={{ color: 'var(--success)' }}>FREE</strong>
              ) : (
                `₹${deliveryFee}`
              )}
            </span>
          </div>

          <div className="summary-row">
            <span>GST & Restaurant Charges (5%)</span>
            <span>₹{tax}</span>
          </div>

          {cartTotal < 299 && (
            <p style={{ fontSize: '0.82rem', color: 'var(--primary)', margin: '8px 0', background: 'var(--primary-light)', padding: '8px 10px', borderRadius: '6px' }}>
              💡 Add ₹{299 - cartTotal} more to get <strong>FREE Delivery</strong>!
            </p>
          )}

          <div className="summary-row total">
            <span>To Pay</span>
            <span>₹{grandTotal}</span>
          </div>

          <button
            className="checkout-btn"
            onClick={() => navigate('/checkout')}
          >
            <span>Proceed to Checkout</span>
            <span>👉</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
