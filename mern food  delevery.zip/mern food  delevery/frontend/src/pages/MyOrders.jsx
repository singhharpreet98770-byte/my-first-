import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { foodApi } from '../services/api';

const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        const data = await foodApi.getOrders();
        setOrders(data);
      } catch (err) {
        console.error('Error fetching orders:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  return (
    <div className="container main-content">
      <h1 className="section-title" style={{ marginTop: '28px', marginBottom: '24px' }}>
        📦 My Order History
      </h1>

      {loading ? (
        <div className="spinner" />
      ) : orders.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">📋</div>
          <h2>No Orders Found</h2>
          <p style={{ color: 'var(--text-muted)', margin: '10px 0 20px 0' }}>
            You haven't placed any orders yet. Treat yourself to something delicious!
          </p>
          <Link to="/" className="cart-btn" style={{ display: 'inline-flex' }}>
            🍽️ Order Food Now
          </Link>
        </div>
      ) : (
        <div>
          {orders.map((order) => {
            const formattedDate = order.createdAt
              ? new Date(order.createdAt).toLocaleString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })
              : 'Recently';

            return (
              <div key={order._id} className="order-card">
                <div className="order-header">
                  <div>
                    <span style={{ fontWeight: 800, color: 'var(--secondary)' }}>
                      Order #{order._id}
                    </span>
                    <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                      📅 Placed on {formattedDate}
                    </p>
                  </div>

                  <span className="status-badge placed">
                    🟢 {order.status || 'Order Placed'}
                  </span>
                </div>

                <div style={{ margin: '16px 0' }}>
                  {order.items && order.items.map((item, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '6px 0',
                        fontSize: '0.9rem',
                        color: 'var(--text-main)'
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span>🍲</span>
                        <span><strong>{item.name}</strong> × {item.quantity}</span>
                      </div>
                      <span>₹{(Number(item.price) * item.quantity)}</span>
                    </div>
                  ))}
                </div>

                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  paddingTop: '12px',
                  borderTop: '1px solid var(--border)',
                  fontSize: '0.9rem'
                }}>
                  <span style={{ color: 'var(--text-muted)' }}>
                    📍 Delivered to: <strong>{order.customer?.address || 'Saved Address'}</strong>
                  </span>
                  <span style={{ fontFamily: 'var(--font-heading)', fontWeight: 800, fontSize: '1.1rem', color: 'var(--primary)' }}>
                    Total: ₹{Number(order.totalAmount || 0)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MyOrders;
