import React, { useState, useEffect } from 'react';
import { adminApi, foodApi } from '../services/api';
import { useAuth } from '../context/AuthContext';

const Admin = () => {
  const { user, login } = useAuth();
  const [activeTab, setActiveTab] = useState('overview'); // overview, orders, menu, users
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState({ message: '', type: '' });

  // Admin inline login states
  const [adminLoginEmail, setAdminLoginEmail] = useState('admin@cravebite.com');
  const [adminLoginPassword, setAdminLoginPassword] = useState('admin123');
  const [adminLoginLoading, setAdminLoginLoading] = useState(false);
  const [adminLoginError, setAdminLoginError] = useState('');

  // Data states
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalOrders: 0,
    pendingOrders: 0,
    deliveredOrders: 0,
    cancelledOrders: 0,
    totalFoods: 0,
    totalUsers: 0
  });
  const [orders, setOrders] = useState([]);
  const [foods, setFoods] = useState([]);
  const [users, setUsers] = useState([]);

  // Filter states
  const [orderStatusFilter, setOrderStatusFilter] = useState('All');
  const [orderSearch, setOrderSearch] = useState('');
  const [foodSearch, setFoodSearch] = useState('');

  // Food Modal / Form states
  const [showFoodModal, setShowFoodModal] = useState(false);
  const [editingFood, setEditingFood] = useState(null);
  const [foodFormData, setFoodFormData] = useState({
    name: '',
    category: 'Biryani',
    price: '',
    description: '',
    image: '',
    isVeg: true,
    rating: 4.8
  });

  const showToast = (msg, type = 'success') => {
    setFeedback({ message: msg, type });
    setTimeout(() => setFeedback({ message: '', type: '' }), 4000);
  };

  // Fetch all admin data
  const loadAdminData = async () => {
    try {
      setLoading(true);
      const [statsRes, ordersRes, foodsRes, usersRes] = await Promise.all([
        adminApi.getStats().catch(() => ({ stats: {} })),
        adminApi.getAllOrders().catch(() => []),
        foodApi.getAllFoods().catch(() => []),
        adminApi.getUsers().catch(() => [])
      ]);

      if (statsRes.stats) setStats(statsRes.stats);
      setOrders(ordersRes || []);
      setFoods(foodsRes || []);
      setUsers(usersRes || []);
    } catch (err) {
      console.error('Error loading admin data:', err);
      showToast('Failed to load some admin data', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  // Update order status handler
  const handleStatusChange = async (orderId, newStatus) => {
    try {
      await adminApi.updateOrderStatus(orderId, newStatus);
      setOrders((prev) =>
        prev.map((o) => (o._id === orderId ? { ...o, status: newStatus } : o))
      );
      showToast(`Order #${orderId} status updated to "${newStatus}"!`);
      // Refresh stats
      const statsRes = await adminApi.getStats();
      if (statsRes.stats) setStats(statsRes.stats);
    } catch (err) {
      showToast(err.message || 'Failed to update order status', 'error');
    }
  };

  // Delete order handler
  const handleDeleteOrder = async (orderId) => {
    if (!window.confirm(`Are you sure you want to delete order #${orderId}?`)) return;
    try {
      await adminApi.deleteOrder(orderId);
      setOrders((prev) => prev.filter((o) => o._id !== orderId));
      showToast(`Order #${orderId} deleted successfully`);
    } catch (err) {
      showToast(err.message || 'Failed to delete order', 'error');
    }
  };

  // Open modal to add new food
  const handleOpenAddFood = () => {
    setEditingFood(null);
    setFoodFormData({
      name: '',
      category: 'Biryani',
      price: '',
      description: '',
      image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
      isVeg: true,
      rating: 4.8
    });
    setShowFoodModal(true);
  };

  // Open modal to edit existing food
  const handleOpenEditFood = (food) => {
    setEditingFood(food);
    setFoodFormData({
      name: food.name,
      category: food.category || 'North Indian',
      price: food.price,
      description: food.description,
      image: food.image,
      isVeg: food.isVeg,
      rating: food.rating || 4.5
    });
    setShowFoodModal(true);
  };

  // Save food (create or update)
  const handleSaveFood = async (e) => {
    e.preventDefault();
    try {
      if (!foodFormData.name || !foodFormData.price || !foodFormData.category) {
        showToast('Please fill in dish name, price and category', 'error');
        return;
      }

      if (editingFood) {
        const res = await adminApi.updateFood(editingFood._id, foodFormData);
        setFoods((prev) => prev.map((f) => (f._id === editingFood._id ? res.data : f)));
        showToast(`"${foodFormData.name}" updated successfully!`);
      } else {
        const res = await adminApi.createFood(foodFormData);
        setFoods((prev) => [res.data, ...prev]);
        showToast(`"${foodFormData.name}" added to menu successfully!`);
      }
      setShowFoodModal(false);
    } catch (err) {
      showToast(err.message || 'Failed to save food item', 'error');
    }
  };

  // Delete food item
  const handleDeleteFood = async (foodId, foodName) => {
    if (!window.confirm(`Are you sure you want to delete "${foodName}" from the menu?`)) return;
    try {
      await adminApi.deleteFood(foodId);
      setFoods((prev) => prev.filter((f) => f._id !== foodId));
      showToast(`"${foodName}" removed from menu.`);
    } catch (err) {
      showToast(err.message || 'Failed to delete food', 'error');
    }
  };

  // Toggle user role
  const handleToggleRole = async (userId, currentRole, userName) => {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    if (!window.confirm(`Change ${userName}'s role to "${newRole}"?`)) return;
    try {
      await adminApi.updateUserRole(userId, newRole);
      setUsers((prev) =>
        prev.map((u) => (u._id === userId ? { ...u, role: newRole } : u))
      );
      showToast(`${userName} is now an ${newRole}!`);
    } catch (err) {
      showToast(err.message || 'Failed to update user role', 'error');
    }
  };

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    const matchesStatus = orderStatusFilter === 'All' || o.status === orderStatusFilter;
    const matchesSearch =
      !orderSearch ||
      o._id?.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer?.name?.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer?.phone?.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer?.city?.toLowerCase().includes(orderSearch.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  // Filtered foods
  const filteredFoods = foods.filter(
    (f) =>
      !foodSearch ||
      f.name?.toLowerCase().includes(foodSearch.toLowerCase()) ||
      f.category?.toLowerCase().includes(foodSearch.toLowerCase())
  );

  const getStatusColor = (status) => {
    switch (status) {
      case 'Delivered':
        return { bg: '#ecfdf5', color: '#059669', border: '#a7f3d0' };
      case 'Cancelled':
        return { bg: '#fef2f2', color: '#dc2626', border: '#fecaca' };
      case 'Out for Delivery':
        return { bg: '#faf5ff', color: '#7c3aed', border: '#e9d5ff' };
      case 'Preparing':
        return { bg: '#fffbeb', color: '#d97706', border: '#fde68a' };
      case 'Confirmed':
        return { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' };
      default:
        return { bg: '#fff7ed', color: '#ea580c', border: '#fed7aa' };
    }
  };

  const handleAdminInlineLogin = async (e) => {
    e.preventDefault();
    setAdminLoginError('');
    setAdminLoginLoading(true);
    try {
      const data = await login(adminLoginEmail, adminLoginPassword);
      if (data?.user?.role !== 'admin') {
        setAdminLoginError('This account does not have administrator privileges.');
      } else {
        showToast('Logged in as Administrator! 🚀');
        loadAdminData();
      }
    } catch (err) {
      setAdminLoginError(err.message || 'Login failed. Please check credentials.');
    } finally {
      setAdminLoginLoading(false);
    }
  };

  // If user is not logged in as Admin, show Admin Authentication Gate
  if (user?.role !== 'admin') {
    return (
      <div className="container main-content" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 'calc(80vh - 100px)' }}>
        <div className="cart-items-card" style={{ maxWidth: '460px', width: '100%', padding: '36px', boxShadow: 'var(--shadow-lg)' }}>
          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
            <div style={{ fontSize: '3.2rem', marginBottom: '10px' }}>🔒</div>
            <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.75rem', color: 'var(--secondary)' }}>
              Admin Access Required
            </h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: '6px' }}>
              Sign in with your administrator account to access the Control Center.
            </p>
          </div>

          {adminLoginError && (
            <div
              style={{
                backgroundColor: '#fee2e2',
                color: '#b91c1c',
                padding: '12px 16px',
                borderRadius: 'var(--radius-sm)',
                marginBottom: '20px',
                fontSize: '0.88rem',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <span>⚠️</span>
              <span>{adminLoginError}</span>
            </div>
          )}

          <form onSubmit={handleAdminInlineLogin}>
            <div className="form-group">
              <label className="form-label" htmlFor="admin-email">
                Admin Email
              </label>
              <input
                id="admin-email"
                type="email"
                className="form-input"
                required
                value={adminLoginEmail}
                onChange={(e) => setAdminLoginEmail(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="admin-password">
                Password
              </label>
              <input
                id="admin-password"
                type="password"
                className="form-input"
                required
                value={adminLoginPassword}
                onChange={(e) => setAdminLoginPassword(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="checkout-btn"
              disabled={adminLoginLoading}
              style={{ marginTop: '20px', opacity: adminLoginLoading ? 0.7 : 1 }}
            >
              {adminLoginLoading ? 'Verifying Admin Access...' : '⚡ Sign In as Admin'}
            </button>
          </form>

          {/* Preset Admin Credentials helper */}
          <div
            style={{
              marginTop: '24px',
              padding: '16px',
              borderRadius: 'var(--radius-sm)',
              background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
              color: '#fff'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <span style={{ fontWeight: 700, fontSize: '0.86rem', color: '#fbbf24' }}>
                🔑 Ready-to-use Admin Accounts:
              </span>
            </div>
            <div style={{ fontSize: '0.8rem', color: '#cbd5e1', lineHeight: '1.6' }}>
              <div>• <strong>admin@cravebite.com</strong> (Pass: <code>admin123</code>)</div>
              <div>• <strong>singhharpreet98770@gmail.com</strong> (Your personal account)</div>
            </div>
            <button
              type="button"
              onClick={() => {
                setAdminLoginEmail('admin@cravebite.com');
                setAdminLoginPassword('admin123');
              }}
              style={{
                marginTop: '10px',
                width: '100%',
                padding: '8px',
                borderRadius: 'var(--radius-sm)',
                border: 'none',
                background: 'var(--primary)',
                color: '#fff',
                fontWeight: 700,
                fontSize: '0.8rem',
                cursor: 'pointer'
              }}
            >
              Auto-Fill & Sign In
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container main-content" style={{ paddingBottom: '60px' }}>
      {/* Toast Feedback */}
      {feedback.message && (
        <div
          style={{
            position: 'fixed',
            top: '80px',
            right: '24px',
            zIndex: 9999,
            padding: '12px 20px',
            borderRadius: 'var(--radius-sm)',
            fontWeight: 600,
            boxShadow: 'var(--shadow-lg)',
            background: feedback.type === 'error' ? 'var(--danger)' : 'var(--success)',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            animation: 'fadeIn 0.3s ease'
          }}
        >
          <span>{feedback.type === 'error' ? '⚠️' : '✅'}</span>
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Admin Header Banner */}
      <div
        style={{
          marginTop: '28px',
          marginBottom: '24px',
          padding: '24px',
          borderRadius: 'var(--radius-md)',
          background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
          color: '#ffffff',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '16px'
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ fontSize: '1.8rem' }}>⚡</span>
            <h1 style={{ fontSize: '1.8rem', fontWeight: 800, margin: 0, fontFamily: 'var(--font-heading)' }}>
              Admin Control Panel
            </h1>
            <span
              style={{
                fontSize: '0.75rem',
                fontWeight: 700,
                textTransform: 'uppercase',
                background: '#10b981',
                padding: '3px 8px',
                borderRadius: '999px',
                letterSpacing: '0.05em'
              }}
            >
              Live Atlas Connected
            </span>
          </div>
          <p style={{ margin: '6px 0 0', color: '#94a3b8', fontSize: '0.95rem' }}>
            Manage food inventory, customer orders, live statuses, and registered users.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={loadAdminData}
            style={{
              padding: '10px 16px',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid #334155',
              background: '#1e293b',
              color: '#f8fafc',
              cursor: 'pointer',
              fontWeight: 600,
              fontSize: '0.88rem'
            }}
          >
            🔄 Refresh Data
          </button>
          <button
            onClick={handleOpenAddFood}
            style={{
              padding: '10px 18px',
              borderRadius: 'var(--radius-sm)',
              border: 'none',
              background: 'var(--primary)',
              color: '#fff',
              cursor: 'pointer',
              fontWeight: 700,
              fontSize: '0.88rem'
            }}
          >
            ➕ Add New Dish
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div
        style={{
          display: 'flex',
          gap: '10px',
          borderBottom: '2px solid var(--border)',
          marginBottom: '28px',
          overflowX: 'auto',
          paddingBottom: '2px'
        }}
      >
        {[
          { id: 'overview', label: '📊 Dashboard Overview' },
          { id: 'orders', label: `📦 Orders (${orders.length})` },
          { id: 'menu', label: `🍔 Menu Items (${foods.length})` },
          { id: 'users', label: `👥 Customers & Users (${users.length})` }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              padding: '12px 20px',
              border: 'none',
              background: 'transparent',
              fontSize: '0.95rem',
              fontWeight: 700,
              cursor: 'pointer',
              color: activeTab === tab.id ? 'var(--primary)' : 'var(--text-muted)',
              borderBottom: activeTab === tab.id ? '3px solid var(--primary)' : '3px solid transparent',
              transition: 'var(--transition)',
              whiteSpace: 'nowrap'
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="spinner" style={{ margin: '40px auto' }} />
      ) : (
        <>
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div>
              {/* Metric Cards Grid */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                  gap: '18px',
                  marginBottom: '32px'
                }}
              >
                <div
                  style={{
                    background: 'var(--bg-card)',
                    padding: '20px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border)',
                    boxShadow: 'var(--shadow-sm)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ color: 'var(--text-muted)', fontWeight: 600, fontSize: '0.88rem' }}>
                      Total Sales
                    </span>
                    <span style={{ fontSize: '1.4rem' }}>💰</span>
                  </div>
                  <h3 style={{ fontSize: '1.8rem', fontWeight: 800, marginTop: '8px', color: 'var(--success)' }}>
                    ₹{stats.totalRevenue || 0}
                  </h3>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    Excludes cancelled orders
                  </span>
                </div>

                <div
                  style={{
                    background: 'var(--bg-card)',
                    padding: '20px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border)',
                    boxShadow: 'var(--shadow-sm)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ color: 'var(--text-muted)', fontWeight: 600, fontSize: '0.88rem' }}>
                      Total Orders
                    </span>
                    <span style={{ fontSize: '1.4rem' }}>📦</span>
                  </div>
                  <h3 style={{ fontSize: '1.8rem', fontWeight: 800, marginTop: '8px', color: 'var(--secondary)' }}>
                    {stats.totalOrders || orders.length}
                  </h3>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    {stats.deliveredOrders || 0} delivered so far
                  </span>
                </div>

                <div
                  style={{
                    background: 'var(--bg-card)',
                    padding: '20px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border)',
                    boxShadow: 'var(--shadow-sm)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ color: 'var(--text-muted)', fontWeight: 600, fontSize: '0.88rem' }}>
                      Pending Orders
                    </span>
                    <span style={{ fontSize: '1.4rem' }}>⏳</span>
                  </div>
                  <h3 style={{ fontSize: '1.8rem', fontWeight: 800, marginTop: '8px', color: 'var(--warning)' }}>
                    {stats.pendingOrders || 0}
                  </h3>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    Need preparation or delivery
                  </span>
                </div>

                <div
                  style={{
                    background: 'var(--bg-card)',
                    padding: '20px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border)',
                    boxShadow: 'var(--shadow-sm)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ color: 'var(--text-muted)', fontWeight: 600, fontSize: '0.88rem' }}>
                      Menu Items
                    </span>
                    <span style={{ fontSize: '1.4rem' }}>🍽️</span>
                  </div>
                  <h3 style={{ fontSize: '1.8rem', fontWeight: 800, marginTop: '8px', color: 'var(--primary)' }}>
                    {foods.length}
                  </h3>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    Active in live catalog
                  </span>
                </div>
              </div>

              {/* Recent Orders Overview */}
              <div
                style={{
                  background: 'var(--bg-card)',
                  borderRadius: 'var(--radius-md)',
                  padding: '24px',
                  border: '1px solid var(--border)',
                  boxShadow: 'var(--shadow-sm)'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                  <h2 style={{ fontSize: '1.25rem', fontWeight: 800 }}>⚡ Recent Orders</h2>
                  <button
                    onClick={() => setActiveTab('orders')}
                    style={{
                      background: 'transparent',
                      border: 'none',
                      color: 'var(--primary)',
                      fontWeight: 700,
                      cursor: 'pointer',
                      fontSize: '0.9rem'
                    }}
                  >
                    View All Orders →
                  </button>
                </div>

                {orders.length === 0 ? (
                  <p style={{ color: 'var(--text-muted)' }}>No orders placed yet.</p>
                ) : (
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                      <thead>
                        <tr style={{ borderBottom: '2px solid var(--border)', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                          <th style={{ padding: '12px' }}>ORDER ID</th>
                          <th style={{ padding: '12px' }}>CUSTOMER</th>
                          <th style={{ padding: '12px' }}>ITEMS</th>
                          <th style={{ padding: '12px' }}>TOTAL</th>
                          <th style={{ padding: '12px' }}>STATUS</th>
                          <th style={{ padding: '12px' }}>QUICK ACTION</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orders.slice(0, 5).map((order) => {
                          const statusStyle = getStatusColor(order.status);
                          return (
                            <tr key={order._id} style={{ borderBottom: '1px solid var(--border)', fontSize: '0.9rem' }}>
                              <td style={{ padding: '12px', fontWeight: 700 }}>#{order._id}</td>
                              <td style={{ padding: '12px' }}>
                                <strong>{order.customer?.name}</strong>
                                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                                  {order.customer?.phone}
                                </div>
                              </td>
                              <td style={{ padding: '12px' }}>
                                {order.items?.map((i) => `${i.name} (×${i.quantity})`).join(', ') || 'N/A'}
                              </td>
                              <td style={{ padding: '12px', fontWeight: 800, color: 'var(--primary)' }}>
                                ₹{order.totalAmount}
                              </td>
                              <td style={{ padding: '12px' }}>
                                <span
                                  style={{
                                    padding: '4px 10px',
                                    borderRadius: '999px',
                                    fontSize: '0.8rem',
                                    fontWeight: 700,
                                    background: statusStyle.bg,
                                    color: statusStyle.color,
                                    border: `1px solid ${statusStyle.border}`
                                  }}
                                >
                                  {order.status || 'Order Placed'}
                                </span>
                              </td>
                              <td style={{ padding: '12px' }}>
                                <select
                                  value={order.status || 'Order Placed'}
                                  onChange={(e) => handleStatusChange(order._id, e.target.value)}
                                  style={{
                                    padding: '6px 10px',
                                    borderRadius: 'var(--radius-sm)',
                                    border: '1px solid var(--border)',
                                    background: 'var(--bg-main)',
                                    fontSize: '0.85rem',
                                    fontWeight: 600,
                                    cursor: 'pointer'
                                  }}
                                >
                                  <option value="Order Placed">Order Placed</option>
                                  <option value="Confirmed">Confirmed</option>
                                  <option value="Preparing">Preparing</option>
                                  <option value="Out for Delivery">Out for Delivery</option>
                                  <option value="Delivered">Delivered</option>
                                  <option value="Cancelled">Cancelled</option>
                                </select>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: ORDERS MANAGEMENT */}
          {activeTab === 'orders' && (
            <div>
              {/* Order Controls Filter */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: '14px',
                  marginBottom: '20px'
                }}
              >
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {['All', 'Order Placed', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'].map(
                    (st) => (
                      <button
                        key={st}
                        onClick={() => setOrderStatusFilter(st)}
                        style={{
                          padding: '7px 14px',
                          borderRadius: 'var(--radius-full)',
                          border: orderStatusFilter === st ? '1px solid var(--primary)' : '1px solid var(--border)',
                          background: orderStatusFilter === st ? 'var(--primary-light)' : 'var(--bg-card)',
                          color: orderStatusFilter === st ? 'var(--primary)' : 'var(--text-main)',
                          fontSize: '0.85rem',
                          fontWeight: 700,
                          cursor: 'pointer'
                        }}
                      >
                        {st}
                      </button>
                    )
                  )}
                </div>

                <input
                  type="text"
                  placeholder="🔍 Search orders by Name, Phone, ID..."
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  style={{
                    padding: '9px 16px',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border)',
                    minWidth: '280px',
                    fontSize: '0.9rem'
                  }}
                />
              </div>

              {filteredOrders.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-state-icon">📦</div>
                  <h3>No matching orders found</h3>
                  <p style={{ color: 'var(--text-muted)' }}>Try selecting a different filter or search term.</p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                  {filteredOrders.map((order) => {
                    const statusStyle = getStatusColor(order.status);
                    return (
                      <div
                        key={order._id}
                        className="order-card"
                        style={{
                          background: 'var(--bg-card)',
                          border: '1px solid var(--border)',
                          borderRadius: 'var(--radius-md)',
                          padding: '20px',
                          boxShadow: 'var(--shadow-sm)'
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
                          <div>
                            <span style={{ fontWeight: 800, fontSize: '1.1rem', color: 'var(--secondary)' }}>
                              Order #{order._id}
                            </span>
                            <span style={{ marginLeft: '12px', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                              📅 {order.createdAt ? new Date(order.createdAt).toLocaleString() : 'Recently'}
                            </span>
                          </div>

                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <span
                              style={{
                                padding: '5px 12px',
                                borderRadius: '999px',
                                fontSize: '0.82rem',
                                fontWeight: 700,
                                background: statusStyle.bg,
                                color: statusStyle.color,
                                border: `1px solid ${statusStyle.border}`
                              }}
                            >
                              ● {order.status || 'Order Placed'}
                            </span>

                            <select
                              value={order.status || 'Order Placed'}
                              onChange={(e) => handleStatusChange(order._id, e.target.value)}
                              style={{
                                padding: '6px 12px',
                                borderRadius: 'var(--radius-sm)',
                                border: '1px solid var(--border)',
                                background: '#fff',
                                fontWeight: 600,
                                fontSize: '0.85rem',
                                cursor: 'pointer'
                              }}
                            >
                              <option value="Order Placed">Order Placed</option>
                              <option value="Confirmed">Confirmed</option>
                              <option value="Preparing">Preparing</option>
                              <option value="Out for Delivery">Out for Delivery</option>
                              <option value="Delivered">Delivered</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>

                            <button
                              onClick={() => handleDeleteOrder(order._id)}
                              title="Delete Order"
                              style={{
                                background: 'transparent',
                                border: '1px solid #fecaca',
                                color: 'var(--danger)',
                                borderRadius: 'var(--radius-sm)',
                                padding: '6px 10px',
                                cursor: 'pointer',
                                fontSize: '0.85rem',
                                fontWeight: 600
                              }}
                            >
                              🗑️
                            </button>
                          </div>
                        </div>

                        {/* Customer details bar */}
                        <div
                          style={{
                            margin: '14px 0',
                            padding: '12px 16px',
                            background: 'var(--bg-main)',
                            borderRadius: 'var(--radius-sm)',
                            display: 'flex',
                            flexWrap: 'wrap',
                            gap: '16px',
                            fontSize: '0.88rem'
                          }}
                        >
                          <div>
                            👤 <strong>Customer:</strong> {order.customer?.name}
                          </div>
                          <div>
                            📞 <strong>Phone:</strong> {order.customer?.phone}
                          </div>
                          <div>
                            ✉️ <strong>Email:</strong> {order.customer?.email}
                          </div>
                          <div>
                            📍 <strong>Address:</strong> {order.customer?.address}, {order.customer?.city} ({order.customer?.pincode})
                          </div>
                          <div>
                            💳 <strong>Payment:</strong> {order.paymentMethod || 'COD'}
                          </div>
                        </div>

                        {/* Ordered Food Items */}
                        <div style={{ margin: '14px 0' }}>
                          <h4 style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                            ORDERED ITEMS
                          </h4>
                          {order.items?.map((item, idx) => (
                            <div
                              key={idx}
                              style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                padding: '6px 0',
                                borderBottom: '1px dashed var(--border)',
                                fontSize: '0.9rem'
                              }}
                            >
                              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <span>🍲</span>
                                <span><strong>{item.name}</strong> × {item.quantity}</span>
                              </div>
                              <span style={{ fontWeight: 700 }}>₹{Number(item.price) * item.quantity}</span>
                            </div>
                          ))}
                        </div>

                        {/* Total Amount Footer */}
                        <div style={{ display: 'flex', justifyContent: 'flex-end', paddingTop: '10px' }}>
                          <span style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--primary)' }}>
                            Grand Total: ₹{order.totalAmount}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: MENU MANAGEMENT */}
          {activeTab === 'menu' && (
            <div>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: '12px',
                  marginBottom: '20px'
                }}
              >
                <input
                  type="text"
                  placeholder="🔍 Search dishes by name or category..."
                  value={foodSearch}
                  onChange={(e) => setFoodSearch(e.target.value)}
                  style={{
                    padding: '9px 16px',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border)',
                    minWidth: '280px',
                    fontSize: '0.9rem'
                  }}
                />

                <button
                  onClick={handleOpenAddFood}
                  className="cart-btn"
                  style={{ display: 'inline-flex', padding: '10px 20px' }}
                >
                  ➕ Add New Dish
                </button>
              </div>

              {/* Foods Grid */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                  gap: '20px'
                }}
              >
                {filteredFoods.map((food) => (
                  <div
                    key={food._id}
                    style={{
                      background: 'var(--bg-card)',
                      borderRadius: 'var(--radius-md)',
                      border: '1px solid var(--border)',
                      overflow: 'hidden',
                      boxShadow: 'var(--shadow-sm)',
                      display: 'flex',
                      flexDirection: 'column'
                    }}
                  >
                    <div style={{ position: 'relative', height: '160px' }}>
                      <img
                        src={food.image}
                        alt={food.name}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      />
                      <span
                        style={{
                          position: 'absolute',
                          top: '10px',
                          left: '10px',
                          background: food.isVeg ? '#10b981' : '#ef4444',
                          color: '#fff',
                          padding: '3px 8px',
                          borderRadius: '999px',
                          fontSize: '0.72rem',
                          fontWeight: 700
                        }}
                      >
                        {food.isVeg ? '🌱 VEG' : '🍗 NON-VEG'}
                      </span>
                      <span
                        style={{
                          position: 'absolute',
                          top: '10px',
                          right: '10px',
                          background: 'rgba(0,0,0,0.7)',
                          color: '#fff',
                          padding: '3px 8px',
                          borderRadius: '999px',
                          fontSize: '0.75rem',
                          fontWeight: 700
                        }}
                      >
                        ★ {food.rating || 4.5}
                      </span>
                    </div>

                    <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', flex: 1 }}>
                      <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>
                        {food.category}
                      </span>
                      <h3 style={{ fontSize: '1.05rem', fontWeight: 800, margin: '4px 0 6px 0', color: 'var(--secondary)' }}>
                        {food.name}
                      </h3>
                      <p
                        style={{
                          fontSize: '0.83rem',
                          color: 'var(--text-muted)',
                          marginBottom: '14px',
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                          flex: 1
                        }}
                      >
                        {food.description}
                      </p>

                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '10px', borderTop: '1px solid var(--border)' }}>
                        <span style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--primary)' }}>
                          ₹{food.price}
                        </span>

                        <div style={{ display: 'flex', gap: '8px' }}>
                          <button
                            onClick={() => handleOpenEditFood(food)}
                            style={{
                              padding: '6px 12px',
                              borderRadius: 'var(--radius-sm)',
                              border: '1px solid var(--border)',
                              background: 'var(--bg-main)',
                              fontWeight: 600,
                              cursor: 'pointer',
                              fontSize: '0.82rem'
                            }}
                          >
                            ✏️ Edit
                          </button>
                          <button
                            onClick={() => handleDeleteFood(food._id, food.name)}
                            style={{
                              padding: '6px 12px',
                              borderRadius: 'var(--radius-sm)',
                              border: '1px solid #fecaca',
                              background: '#fef2f2',
                              color: 'var(--danger)',
                              fontWeight: 600,
                              cursor: 'pointer',
                              fontSize: '0.82rem'
                            }}
                          >
                            🗑️ Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: USERS MANAGEMENT */}
          {activeTab === 'users' && (
            <div
              style={{
                background: 'var(--bg-card)',
                borderRadius: 'var(--radius-md)',
                padding: '24px',
                border: '1px solid var(--border)',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <div style={{ marginBottom: '20px' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 800 }}>👥 Registered Customers & Administrators</h2>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem' }}>
                  Accounts registered in your MongoDB Atlas database.
                </p>
              </div>

              {users.length === 0 ? (
                <p style={{ color: 'var(--text-muted)' }}>No registered users found.</p>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                    <thead>
                      <tr style={{ borderBottom: '2px solid var(--border)', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                        <th style={{ padding: '12px' }}>NAME</th>
                        <th style={{ padding: '12px' }}>EMAIL</th>
                        <th style={{ padding: '12px' }}>PHONE</th>
                        <th style={{ padding: '12px' }}>CITY</th>
                        <th style={{ padding: '12px' }}>ROLE</th>
                        <th style={{ padding: '12px' }}>JOINED</th>
                        <th style={{ padding: '12px' }}>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((u) => (
                        <tr key={u._id} style={{ borderBottom: '1px solid var(--border)', fontSize: '0.9rem' }}>
                          <td style={{ padding: '12px', fontWeight: 700 }}>{u.name}</td>
                          <td style={{ padding: '12px' }}>{u.email}</td>
                          <td style={{ padding: '12px' }}>{u.phone || 'N/A'}</td>
                          <td style={{ padding: '12px' }}>{u.city || 'New Delhi'}</td>
                          <td style={{ padding: '12px' }}>
                            <span
                              style={{
                                padding: '4px 10px',
                                borderRadius: '999px',
                                fontSize: '0.78rem',
                                fontWeight: 700,
                                textTransform: 'uppercase',
                                background: u.role === 'admin' ? '#eff6ff' : '#f1f5f9',
                                color: u.role === 'admin' ? '#2563eb' : '#475569',
                                border: u.role === 'admin' ? '1px solid #bfdbfe' : '1px solid #cbd5e1'
                              }}
                            >
                              {u.role === 'admin' ? '⭐ Admin' : '👤 User'}
                            </span>
                          </td>
                          <td style={{ padding: '12px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                            {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'Recent'}
                          </td>
                          <td style={{ padding: '12px' }}>
                            <button
                              onClick={() => handleToggleRole(u._id, u.role, u.name)}
                              style={{
                                padding: '6px 12px',
                                borderRadius: 'var(--radius-sm)',
                                border: '1px solid var(--border)',
                                background: 'var(--bg-main)',
                                fontSize: '0.82rem',
                                fontWeight: 600,
                                cursor: 'pointer'
                              }}
                            >
                              {u.role === 'admin' ? 'Demote to User' : 'Promote to Admin'}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* MODAL: ADD / EDIT FOOD ITEM */}
      {showFoodModal && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 10000,
            padding: '20px'
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowFoodModal(false);
          }}
        >
          <div
            style={{
              background: '#fff',
              borderRadius: 'var(--radius-md)',
              width: '100%',
              maxWidth: '540px',
              maxHeight: '90vh',
              overflowY: 'auto',
              padding: '28px',
              boxShadow: 'var(--shadow-lg)',
              animation: 'fadeIn 0.2s ease'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2 style={{ fontSize: '1.3rem', fontWeight: 800 }}>
                {editingFood ? '✏️ Edit Dish' : '➕ Add New Dish to Menu'}
              </h2>
              <button
                onClick={() => setShowFoodModal(false)}
                style={{
                  background: 'transparent',
                  border: 'none',
                  fontSize: '1.4rem',
                  cursor: 'pointer',
                  color: 'var(--text-muted)'
                }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveFood} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>
                  Dish Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Special Butter Chicken"
                  value={foodFormData.name}
                  onChange={(e) => setFoodFormData({ ...foodFormData, name: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border)',
                    fontSize: '0.9rem'
                  }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>
                    Category *
                  </label>
                  <select
                    value={foodFormData.category}
                    onChange={(e) => setFoodFormData({ ...foodFormData, category: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '10px 14px',
                      borderRadius: 'var(--radius-sm)',
                      border: '1px solid var(--border)',
                      fontSize: '0.9rem',
                      background: '#fff'
                    }}
                  >
                    <option value="Biryani">Biryani</option>
                    <option value="North Indian">North Indian</option>
                    <option value="South Indian">South Indian</option>
                    <option value="Rolls">Rolls</option>
                    <option value="Desserts">Desserts</option>
                    <option value="Beverages">Beverages</option>
                    <option value="Fast Food">Fast Food</option>
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>
                    Price (₹) *
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    placeholder="e.g. 299"
                    value={foodFormData.price}
                    onChange={(e) => setFoodFormData({ ...foodFormData, price: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '10px 14px',
                      borderRadius: 'var(--radius-sm)',
                      border: '1px solid var(--border)',
                      fontSize: '0.9rem'
                    }}
                  />
                </div>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>
                  Image URL *
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://images.unsplash.com/..."
                  value={foodFormData.image}
                  onChange={(e) => setFoodFormData({ ...foodFormData, image: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border)',
                    fontSize: '0.9rem'
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>
                  Description *
                </label>
                <textarea
                  required
                  rows="3"
                  placeholder="Appetizing description of ingredients, spices, and flavor profile..."
                  value={foodFormData.description}
                  onChange={(e) => setFoodFormData({ ...foodFormData, description: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border)',
                    fontSize: '0.9rem',
                    fontFamily: 'inherit',
                    resize: 'vertical'
                  }}
                />
              </div>

              <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontWeight: 600, fontSize: '0.9rem' }}>
                  <input
                    type="checkbox"
                    checked={foodFormData.isVeg}
                    onChange={(e) => setFoodFormData({ ...foodFormData, isVeg: e.target.checked })}
                    style={{ width: '18px', height: '18px' }}
                  />
                  <span>🌱 Pure Vegetarian Dish</span>
                </label>
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '12px' }}>
                <button
                  type="button"
                  onClick={() => setShowFoodModal(false)}
                  style={{
                    flex: 1,
                    padding: '12px',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border)',
                    background: 'var(--bg-main)',
                    fontWeight: 600,
                    cursor: 'pointer'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="cart-btn"
                  style={{ flex: 2, padding: '12px', justifyContent: 'center' }}
                >
                  {editingFood ? '💾 Save Changes' : '➕ Add to Menu'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;
