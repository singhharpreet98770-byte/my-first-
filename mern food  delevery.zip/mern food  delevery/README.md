# 🍕 CraveBite - MERN Stack Food Delivery App

A complete, beginner-friendly yet production-structured **MERN Stack** (MongoDB, Express, React, Node.js) Food Delivery Application. It allows customers to browse menu items by category, search foods, manage a shopping cart, place orders with delivery details and payment methods, and save/view orders directly from a MongoDB database.

---

## 🌟 Key Features

- **🍔 Menu Browsing & Filtering:** Filter foods by category (*Pizza, Burger, Pasta, Salad, Dessert, Drinks*) or use live text search.
- **🛒 Interactive Cart:** Add items, dynamically adjust quantities (`+` / `-`), auto-calculate subtotals, taxes, and free delivery thresholds.
- **💾 LocalStorage Cart Sync:** Cart state persists across page refreshes using React Context.
- **🚀 Checkout & Order Placement:** Fill delivery address and contact information, select payment method (*Cash on Delivery, Card, UPI*).
- **📦 Order History & MongoDB Persistence:** Saved orders stored in MongoDB and viewable on the *My Orders* page.
- **✨ Auto-Seeder & Sample Foods:** Includes high-resolution food images, vegetarian badges, and ratings.

---

## 📂 Project Structure

```text
food-delivery-app/
├── backend/
│   ├── config/
│   │   └── db.js                 # MongoDB Connection via Mongoose
│   ├── controllers/
│   │   ├── foodController.js     # Food CRUD & Auto-seeder handlers
│   │   └── orderController.js    # Order Creation & Retrieval handlers
│   ├── data/
│   │   ├── sampleFoods.js        # Realistic sample food dataset
│   │   └── seeder.js             # CLI Seed script
│   ├── models/
│   │   ├── Food.js               # Mongoose Schema for Foods
│   │   └── Order.js              # Mongoose Schema for Orders
│   ├── routes/
│   │   ├── foodRoutes.js         # API routes for /api/foods
│   │   └── orderRoutes.js        # API routes for /api/orders
│   ├── .env                      # Backend Environment Variables
│   ├── package.json              # Backend Dependencies & Scripts
│   └── server.js                 # Express Application Entry Point
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── FoodCard.jsx      # Food card with image & add-to-cart buttons
│   │   │   ├── FoodFilter.jsx    # Category filter pills
│   │   │   ├── Navbar.jsx        # Navigation bar with live cart count badge
│   │   │   └── Footer.jsx        # Footer branding
│   │   ├── context/
│   │   │   └── CartContext.jsx   # State management for cart (React Context)
│   │   ├── pages/
│   │   │   ├── Home.jsx          # Hero banner + Menu listing + Search
│   │   │   ├── Cart.jsx          # Shopping cart breakdown & bill summary
│   │   │   ├── Checkout.jsx      # Delivery address form & payment picker
│   │   │   ├── OrderSuccess.jsx  # Confirmation page with Order ID
│   │   │   └── MyOrders.jsx      # Order history from MongoDB
│   │   ├── services/
│   │   │   └── api.js            # Frontend API client
│   │   ├── styles/
│   │   │   └── index.css         # Modern, responsive CSS styling
│   │   ├── App.jsx               # Route definitions
│   │   └── main.jsx              # React DOM entry point
│   ├── index.html                # HTML template with Google Fonts
│   ├── package.json              # Frontend Dependencies
│   └── vite.config.js            # Vite configuration & dev proxy
│
├── package.json                  # Root scripts
└── README.md                     # Documentation & Setup Guide
```

---

## ⚙️ Prerequisites

Before running the project, make sure you have installed:
1. [Node.js](https://nodejs.org/) (v16 or higher)
2. [MongoDB](https://www.mongodb.com/try/download/community) installed and running locally on `mongodb://127.0.0.1:27017` (or you can use MongoDB Atlas URI in `backend/.env`).

---

## 🚀 How to Run the Project (Step-by-Step)

### Step 1: Clone or Extract the Project
Extract the provided `food-delivery-app.zip` or navigate to the project directory:
```bash
cd food-delivery-app
```

---

### Step 2: Set Up and Run the Backend

1. Open a terminal and navigate to the backend folder:
   ```bash
   cd backend
   ```

2. Install backend dependencies:
   ```bash
   npm install
   ```

3. *(Optional)* Seed initial food items into MongoDB:
   ```bash
   npm run seed
   ```

4. Start the backend server:
   ```bash
   npm start
   # or with nodemon for auto-restart:
   npm run dev
   ```

The backend server will run at **`http://localhost:5000`**.

---

### Step 3: Set Up and Run the Frontend

1. Open a **new / second terminal window** and navigate to the frontend folder:
   ```bash
   cd frontend
   ```

2. Install frontend dependencies:
   ```bash
   npm install
   ```

3. Start the Vite React development server:
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to:
   👉 **`http://localhost:3000`** (or the URL displayed in the terminal)

---

## 📡 REST API Endpoints

### 🔑 Authentication API
| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/auth/register` | Register new user account with hashed password |
| `POST` | `/api/auth/login` | Login user & receive JWT Bearer token |
| `GET` | `/api/auth/profile` | Get current logged-in user profile (Protected) |

### 🍔 Foods API
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/foods` | Get all food items (supports `?category=Pizza&search=margherita`) |
| `GET` | `/api/foods/:id` | Get single food item by ID |
| `POST` | `/api/foods` | Create a new food item |
| `POST` | `/api/foods/seed` | Reset and seed sample foods |

### 📦 Orders API
| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/orders` | Create a new order with items and customer details |
| `GET` | `/api/orders` | Get all placed orders (latest first) |
| `GET` | `/api/orders/:id` | Get single order details |
| `PUT` | `/api/orders/:id/status` | Update order status |

---

## 💡 How MERN Stack Concepts are Applied

1. **MongoDB (Mongoose):**
   - Structured schemas in `backend/models/Food.js` and `backend/models/Order.js`.
   - Data relationships: Orders store ordered items referencing food items.

2. **Express & Node.js:**
   - RESTful API routing in `backend/routes/` and business logic separated into `backend/controllers/`.
   - Middleware for CORS, JSON request parsing, and error handling.

3. **React.js:**
   - Single Page Application (SPA) routing with `react-router-dom`.
   - Global state management for Cart and quantities with `React Context API` (`CartContext.jsx`).
   - Clean, modular component architecture (`Navbar`, `FoodCard`, `FoodFilter`, `Footer`).
   - Persistent client-side caching with `localStorage`.

---

## 📄 License
MIT License - Feel free to use and adapt this project for your portfolio or learning journey!
