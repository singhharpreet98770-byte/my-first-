const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const User = require('../models/User');

// Middleware to verify JWT and authenticate user
const protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      // Extract Bearer token
      token = req.headers.authorization.split(' ')[1];

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'super_cravebite_food_delivery_jwt_secret_key_2024');

      if (mongoose.connection.readyState !== 1) {
        const { memoryUsers } = require('../controllers/authController');
        const user = memoryUsers ? memoryUsers.find((u) => u._id === decoded.id) : null;
        if (!user) {
          req.user = { _id: decoded.id, name: 'Guest User', email: 'user@example.com' };
        } else {
          req.user = user;
        }
        return next();
      }

      // Fetch user without password from MongoDB
      req.user = await User.findById(decoded.id).select('-password');

      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'User account no longer exists'
        });
      }

      next();
    } catch (error) {
      console.error('JWT Auth Error:', error.message);
      return res.status(401).json({
        success: false,
        message: 'Not authorized, token failed or expired'
      });
    }
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized, no token provided'
    });
  }
};

// Optional auth middleware (sets req.user if token is valid, but allows guest if no token)
const optionalAuth = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'super_cravebite_food_delivery_jwt_secret_key_2024');

      if (mongoose.connection.readyState !== 1) {
        const { memoryUsers } = require('../controllers/authController');
        const user = memoryUsers ? memoryUsers.find((u) => u._id === decoded.id) : null;
        req.user = user || { _id: decoded.id, email: 'user@example.com' };
        return next();
      }

      req.user = await User.findById(decoded.id).select('-password');
    } catch (error) {
      req.user = null;
    }
  }
  next();
};

module.exports = { protect, optionalAuth };
