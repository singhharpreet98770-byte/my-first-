const mongoose = require('mongoose');
const Order = require('../models/Order');

// In-memory orders store for offline mode
let memoryOrders = [
  {
    _id: 'ORD-DEMO-1001',
    customer: {
      name: 'Harpreet Singh',
      email: 'harpreet@example.com',
      phone: '+91 98765 43210',
      address: 'Plot 42, Connaught Place',
      city: 'New Delhi',
      pincode: '110001'
    },
    items: [
      {
        foodId: 'offline-food-1',
        name: 'Hyderabadi Dum Chicken Biryani',
        price: 349,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80'
      },
      {
        foodId: 'offline-food-3',
        name: 'Royal Paneer Butter Masala',
        price: 289,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=80'
      }
    ],
    totalAmount: 987,
    paymentMethod: 'UPI / Online',
    status: 'Order Placed',
    createdAt: new Date().toISOString()
  }
];

/**
 * @desc    Place a new food order
 * @route   POST /api/orders
 * @access  Public
 */
const createOrder = async (req, res) => {
  try {
    const { customer, items, totalAmount, paymentMethod } = req.body;

    // Basic validations
    if (!customer || !customer.name || !customer.email || !customer.phone || !customer.address) {
      return res.status(400).json({
        success: false,
        message: 'Please provide full customer details (name, email, phone, address)'
      });
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Cart is empty. Please add at least one food item to order.'
      });
    }

    if (!totalAmount || totalAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid total amount'
      });
    }

    // Format items
    const formattedItems = items.map((item) => ({
      foodId: item._id || item.foodId,
      name: item.name,
      price: Number(item.price),
      quantity: Number(item.quantity) || 1,
      image: item.image
    }));

    const orderData = {
      _id: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
      user: req.user ? req.user._id : null,
      customer: {
        name: customer.name.trim(),
        email: customer.email.trim(),
        phone: customer.phone.trim(),
        address: customer.address.trim(),
        city: customer.city ? customer.city.trim() : 'New Delhi',
        pincode: customer.pincode ? customer.pincode.trim() : '110001'
      },
      items: formattedItems,
      totalAmount: Number(totalAmount.toFixed(2)),
      paymentMethod: paymentMethod || 'UPI / Online',
      status: 'Order Placed',
      createdAt: new Date().toISOString()
    };

    // If MongoDB is offline, save to in-memory store
    if (mongoose.connection.readyState !== 1) {
      memoryOrders.unshift(orderData);
      return res.status(201).json({
        success: true,
        message: 'Order placed successfully! 🍕 (In-Memory Mode)',
        data: orderData
      });
    }

    // Create and save new order in MongoDB
    const order = await Order.create(orderData);

    res.status(201).json({
      success: true,
      message: 'Order placed successfully! 🍕',
      data: order
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error placing order',
      error: error.message
    });
  }
};

/**
 * @desc    Get all orders
 * @route   GET /api/orders
 * @access  Public
 */
const getOrders = async (req, res) => {
  try {
    const userFilter = {};
    if (req.user) {
      userFilter.$or = [
        { user: req.user._id },
        { 'customer.email': req.user.email }
      ];
    } else if (req.query.email) {
      userFilter['customer.email'] = req.query.email;
    }

    // If MongoDB is offline, return in-memory orders
    if (mongoose.connection.readyState !== 1) {
      let filtered = [...memoryOrders];
      if (req.user) {
        filtered = filtered.filter(
          (o) => (o.user && o.user.toString() === req.user._id.toString()) || (o.customer && o.customer.email === req.user.email)
        );
      } else if (req.query.email) {
        filtered = filtered.filter((o) => o.customer && o.customer.email === req.query.email);
      }

      return res.status(200).json({
        success: true,
        count: filtered.length,
        data: filtered
      });
    }

    const orders = await Order.find(userFilter).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: orders.length,
      data: orders
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error fetching orders',
      error: error.message
    });
  }
};

/**
 * @desc    Get single order by ID
 * @route   GET /api/orders/:id
 * @access  Public
 */
const getOrderById = async (req, res) => {
  try {
    if (mongoose.connection.readyState !== 1) {
      const order = memoryOrders.find((o) => o._id === req.params.id);
      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }
      return res.status(200).json({
        success: true,
        data: order
      });
    }

    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error fetching order details',
      error: error.message
    });
  }
};

/**
 * @desc    Update order status
 * @route   PUT /api/orders/:id/status
 * @access  Public
 */
const updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const allowedStatuses = ['Order Placed', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'];

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Allowed values: ${allowedStatuses.join(', ')}`
      });
    }

    if (mongoose.connection.readyState !== 1) {
      const order = memoryOrders.find((o) => o._id === req.params.id);
      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }
      order.status = status;
      return res.status(200).json({
        success: true,
        message: 'Order status updated successfully',
        data: order
      });
    }

    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Order status updated successfully',
      data: order
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error updating order status',
      error: error.message
    });
  }
};

module.exports = {
  createOrder,
  getOrders,
  getOrderById,
  updateOrderStatus
};
