const mongoose = require('mongoose');
const Food = require('../models/Food');
let sampleFoods = require('../data/sampleFoods');

// In-memory food store for when MongoDB is offline
let memoryFoods = sampleFoods.map((f, i) => ({
  ...f,
  _id: `offline-food-${i + 1}`,
  createdAt: new Date().toISOString()
}));

/**
 * @desc    Get all food items (with optional category & search filter)
 * @route   GET /api/foods
 * @access  Public
 */
const getFoods = async (req, res) => {
  try {
    const { category, search } = req.query;

    // If MongoDB is offline, serve in-memory fallback immediately
    if (mongoose.connection.readyState !== 1) {
      let foods = [...memoryFoods];

      if (category && category.toLowerCase() !== 'all') {
        foods = foods.filter((f) => f.category.toLowerCase() === category.toLowerCase());
      }

      if (search) {
        foods = foods.filter(
          (f) =>
            f.name.toLowerCase().includes(search.toLowerCase()) ||
            f.description.toLowerCase().includes(search.toLowerCase())
        );
      }

      return res.status(200).json({
        success: true,
        count: foods.length,
        data: foods
      });
    }

    let query = {};

    // Filter by category if provided and not "All"
    if (category && category.toLowerCase() !== 'all') {
      query.category = { $regex: new RegExp(`^${category}$`, 'i') };
    }

    // Filter by search keyword (in name or description)
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    let foods = await Food.find(query).sort({ createdAt: -1 });

    // Auto-seed if database is completely empty and no filters were applied
    if (foods.length === 0 && !category && !search) {
      const count = await Food.countDocuments();
      if (count === 0) {
        console.log('Database empty on first request, auto-seeding sample foods...');
        foods = await Food.insertMany(sampleFoods);
      }
    }

    res.status(200).json({
      success: true,
      count: foods.length,
      data: foods
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error fetching food items',
      error: error.message
    });
  }
};

/**
 * @desc    Get single food item by ID
 * @route   GET /api/foods/:id
 * @access  Public
 */
const getFoodById = async (req, res) => {
  try {
    const food = await Food.findById(req.params.id);
    if (!food) {
      return res.status(404).json({
        success: false,
        message: 'Food item not found'
      });
    }

    res.status(200).json({
      success: true,
      data: food
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error fetching food item',
      error: error.message
    });
  }
};

/**
 * @desc    Create a new food item
 * @route   POST /api/foods
 * @access  Public
 */
const createFood = async (req, res) => {
  try {
    const { name, description, price, image, category, rating, isVeg } = req.body;

    if (!name || !description || !price || !image || !category) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields (name, description, price, image, category)'
      });
    }

    const food = await Food.create({
      name,
      description,
      price: Number(price),
      image,
      category,
      rating: rating ? Number(rating) : 4.5,
      isVeg: Boolean(isVeg)
    });

    res.status(201).json({
      success: true,
      message: 'Food item created successfully',
      data: food
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error creating food item',
      error: error.message
    });
  }
};

/**
 * @desc    Seed sample food items into database
 * @route   POST /api/foods/seed
 * @access  Public
 */
const seedFoods = async (req, res) => {
  try {
    await Food.deleteMany();
    const seededFoods = await Food.insertMany(sampleFoods);

    res.status(201).json({
      success: true,
      message: `Successfully seeded ${seededFoods.length} food items`,
      data: seededFoods
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to seed food items',
      error: error.message
    });
  }
};

/**
 * @desc    Update a food item
 * @route   PUT /api/foods/:id
 * @access  Public / Admin
 */
const updateFood = async (req, res) => {
  try {
    const { name, description, price, image, category, rating, isVeg } = req.body;

    if (mongoose.connection.readyState !== 1) {
      const index = memoryFoods.findIndex((f) => f._id === req.params.id);
      if (index === -1) {
        return res.status(404).json({ success: false, message: 'Food item not found' });
      }
      memoryFoods[index] = {
        ...memoryFoods[index],
        ...(name && { name }),
        ...(description && { description }),
        ...(price !== undefined && { price: Number(price) }),
        ...(image && { image }),
        ...(category && { category }),
        ...(rating !== undefined && { rating: Number(rating) }),
        ...(isVeg !== undefined && { isVeg: Boolean(isVeg) })
      };
      return res.status(200).json({
        success: true,
        message: 'Food item updated successfully',
        data: memoryFoods[index]
      });
    }

    const food = await Food.findByIdAndUpdate(
      req.params.id,
      {
        ...(name && { name }),
        ...(description && { description }),
        ...(price !== undefined && { price: Number(price) }),
        ...(image && { image }),
        ...(category && { category }),
        ...(rating !== undefined && { rating: Number(rating) }),
        ...(isVeg !== undefined && { isVeg: Boolean(isVeg) })
      },
      { new: true, runValidators: true }
    );

    if (!food) {
      return res.status(404).json({
        success: false,
        message: 'Food item not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Food item updated successfully',
      data: food
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error updating food item',
      error: error.message
    });
  }
};

/**
 * @desc    Delete a food item
 * @route   DELETE /api/foods/:id
 * @access  Public / Admin
 */
const deleteFood = async (req, res) => {
  try {
    if (mongoose.connection.readyState !== 1) {
      const index = memoryFoods.findIndex((f) => f._id === req.params.id);
      if (index === -1) {
        return res.status(404).json({ success: false, message: 'Food item not found' });
      }
      memoryFoods.splice(index, 1);
      return res.status(200).json({
        success: true,
        message: 'Food item deleted successfully'
      });
    }

    const food = await Food.findByIdAndDelete(req.params.id);

    if (!food) {
      return res.status(404).json({
        success: false,
        message: 'Food item not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Food item deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server Error deleting food item',
      error: error.message
    });
  }
};

module.exports = {
  getFoods,
  getFoodById,
  createFood,
  updateFood,
  deleteFood,
  seedFoods
};
