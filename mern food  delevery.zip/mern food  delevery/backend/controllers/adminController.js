﻿const mongoose = require('mongoose');
const Order = require('../models/Order');
const Food = require('../models/Food');
const User = require('../models/User');

/**
 * @desc    Get Admin Dashboard Stats & Metrics
 * @route   GET /api/admin/stats
 * @access  Public / Admin
 */
exports.getDashboardStats = async (req, res) => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return res.status(200).json({
        success: true,
        stats: {
          totalRevenue: 698,
          totalOrders: 1,
          pendingOrders: 1,
          deliveredOrders: 0,
          cancelledOrders: 0,
          totalFoods: 12,
          totalUsers: 2
        },
        recentOrders: []
      });
    }

    const totalOrders = await Order.countDocuments();
    const pendingOrders = await Order.countDocuments({
      status: { $in: ['Order Placed', 'Confirmed', 'Preparing', 'Out for Delivery'] }
    });
    const deliveredOrders = await Order.countDocuments({ status: 'Delivered' });
    const cancelledOrders = await Order.countDocuments({ status: 'Cancelled' });

    const revenueAgg = await Order.aggregate([
      { $match: { status: { $ne: 'Cancelled' } } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } }
    ]);
    const totalRevenue = revenueAgg.length > 0 ? revenueAgg[0].total : 0;

    const totalFoods = await Food.countDocuments();
    const totalUsers = await User.countDocuments();
    const recentOrders = await Order.find().sort({ createdAt: -1 }).limit(5);

    res.status(200).json({
      success: true,
      stats: {
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        totalOrders,
        pendingOrders,
        deliveredOrders,
        cancelledOrders,
        totalFoods,
        totalUsers
      },
      recentOrders
    });
  } catch (error) {
    console.error('Admin Stats Error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching admin stats',
      error: error.message
    });
  }
};

/**
 * @desc    Get all orders for admin with optional status and search filter
 * @route   GET /api/admin/orders
 * @access  Public / Admin
 */
exports.getAllOrders = async (req, res) => {
  try {
    const { status, search } = req.query;
    let query = {};

    if (status && status !== 'All') {
      query.status = status;
    }

    if (search) {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { _id: searchRegex },
        { 'customer.name': searchRegex },
        { 'customer.email': searchRegex },
        { 'customer.phone': searchRegex },
        { 'customer.city': searchRegex }
      ];
    }

    if (mongoose.connection.readyState !== 1) {
      return res.status(200).json({
        success: true,
        count: 0,
        data: []
      });
    }

    const orders = await Order.find(query).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: orders.length,
      data: orders
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error fetching admin orders',
      error: error.message
    });
  }
};

/**
 * @desc    Delete an order
 * @route   DELETE /api/admin/orders/:id
 * @access  Public / Admin
 */
exports.deleteOrder = async (req, res) => {
  try {
    const order = await Order.findByIdAndDelete(req.params.id);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Order deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error deleting order',
      error: error.message
    });
  }
};

/**
 * @desc    Get all registered users
 * @route   GET /api/admin/users
 * @access  Public / Admin
 */
exports.getAllUsers = async (req, res) => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return res.status(200).json({
        success: true,
        count: 0,
        data: []
      });
    }

    const users = await User.find().select('-password').sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: users.length,
      data: users
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error fetching users',
      error: error.message
    });
  }
};

/**
 * @desc    Update user role (user/admin)
 * @route   PUT /api/admin/users/:id/role
 * @access  Public / Admin
 */
exports.updateUserRole = async (req, res) => {
  try {
    const { role } = req.body;
    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid role. Must be user or admin.'
      });
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      message: `User role updated to ${role}`,
      data: user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error updating user role',
      error: error.message
    });
  }
};
