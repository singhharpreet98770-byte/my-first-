const sampleFoods = [
  {
    name: "Hyderabadi Dum Chicken Biryani",
    description: "Aromatic long-grain basmati rice layered with spiced marinated chicken, saffron, brown onions, and royal herbs. Served with Mirchi ka Salan & Raita.",
    price: 349,
    category: "Biryani",
    rating: 4.9,
    isVeg: false,
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Royal Paneer Butter Masala",
    description: "Fresh cottage cheese cubes simmered in a velvety, rich tomato cashew gravy with real butter and aromatic kasturi methi.",
    price: 289,
    category: "North Indian",
    rating: 4.8,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Classic Murgh Makhani (Butter Chicken)",
    description: "Tender tandoori chicken cooked in slow-simmered silky tomato-butter gravy with fenugreek and a touch of organic honey.",
    price: 379,
    category: "North Indian",
    rating: 4.9,
    isVeg: false,
    image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Mysore Masala Dosa",
    description: "Golden crispy fermented crepe smeared with spicy red chutney and stuffed with seasoned potato masala. Served with hot Sambar and 2 chutneys.",
    price: 179,
    category: "South Indian",
    rating: 4.7,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Amritsari Chole Bhature Special",
    description: "Spicy and tangy Punjabi pindi chole cooked with dark tea-leaf brew, served with 2 jumbo fluffy bhature, pickled chillies, and onions.",
    price: 199,
    category: "North Indian",
    rating: 4.8,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Dilli 6 Samosa Chaat",
    description: "Crispy fried potato samosas broken and smothered with chole, chilled sweet curd, tangy tamarind saunth chutney, mint chutney, and nylon sev.",
    price: 139,
    category: "Street Food",
    rating: 4.6,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Tandoori Paneer Tikka Desi Pizza",
    description: "Crispy handcrafted thin crust topped with spicy chargrilled paneer cubes, crunchy capsicum, red onions, mozzarella, and makhani drizzle.",
    price: 329,
    category: "Pizza",
    rating: 4.7,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Chicken Tikka Makhani Pizza",
    description: "Loaded with smoky tandoori chicken tikka, rich makhani sauce, mozzarella cheese, and fresh coriander on a golden crust.",
    price: 389,
    category: "Pizza",
    rating: 4.8,
    isVeg: false,
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Crispy Desi Aloo Tikki Burger",
    description: "Golden spiced potato and pea patty with crunchy lettuce, onions, juicy tomatoes, and mint-mayo dressing inside toasted buns.",
    price: 129,
    category: "Burger",
    rating: 4.5,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Hot Shahi Gulab Jamun with Rabri (2 Pcs)",
    description: "Soft melt-in-mouth mawa dumplings soaked in green cardamom rose sugar syrup, served with creamy thickened rabri and dry fruit slivers.",
    price: 159,
    category: "Dessert",
    rating: 4.9,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Kesari Mango Lassi",
    description: "Rich, thick, slow-churned yogurt smoothie blended with sweet Ratnagiri Alphonso mango pulp and topped with saffron strands.",
    price: 119,
    category: "Drinks",
    rating: 4.8,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "Special Punjabi Veg Thali Deluxe",
    description: "Complete feast with Paneer Butter Masala, Dal Makhani, Mixed Veg, Jeera Rice, 2 Butter Naans, Raita, Salad & 1 Gulab Jamun.",
    price: 399,
    category: "North Indian",
    rating: 4.9,
    isVeg: true,
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80"
  }
];

module.exports = sampleFoods;
