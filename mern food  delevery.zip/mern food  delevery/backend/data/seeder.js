const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });
const mongoose = require('mongoose');
const Food = require('../models/Food');
const Order = require('../models/Order');
const sampleFoods = require('./sampleFoods');

const seedDatabase = async () => {
  try {
    const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/food_delivery_db';
    console.log(`Connecting to MongoDB at: ${mongoUri}...`);
    await mongoose.connect(mongoUri);

    console.log('Clearing existing food items...');
    await Food.deleteMany();

    console.log('Inserting sample food items...');
    const createdFoods = await Food.insertMany(sampleFoods);

    console.log(`🎉 Successfully seeded ${createdFoods.length} food items into the database!`);
    process.exit(0);
  } catch (error) {
    console.error(`❌ Error seeding database: ${error.message}`);
    process.exit(1);
  }
};

seedDatabase();
