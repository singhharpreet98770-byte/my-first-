const express = require('express');
const router = express.Router();
const {
  getFoods,
  getFoodById,
  createFood,
  updateFood,
  deleteFood,
  seedFoods
} = require('../controllers/foodController');

// Routes for /api/foods
router.route('/')
  .get(getFoods)
  .post(createFood);

router.route('/seed')
  .post(seedFoods);

router.route('/:id')
  .get(getFoodById)
  .put(updateFood)
  .delete(deleteFood);

module.exports = router;
