const express = require('express');
const router = express.Router();
const {
  createOrder,
  getOrders,
  getOrderById,
  updateOrderStatus
} = require('../controllers/orderController');
const { optionalAuth } = require('../middleware/authMiddleware');

// Routes for /api/orders
router.route('/')
  .post(optionalAuth, createOrder)
  .get(optionalAuth, getOrders);

router.route('/:id')
  .get(getOrderById);

router.route('/:id/status')
  .put(updateOrderStatus);

module.exports = router;
