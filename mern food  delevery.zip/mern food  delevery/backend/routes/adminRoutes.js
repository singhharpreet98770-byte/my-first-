const express = require('express');
const router = express.Router();
const {
  getDashboardStats,
  getAllOrders,
  deleteOrder,
  getAllUsers,
  updateUserRole
} = require('../controllers/adminController');

// Admin endpoints
router.get('/stats', getDashboardStats);
router.get('/orders', getAllOrders);
router.delete('/orders/:id', deleteOrder);
router.get('/users', getAllUsers);
router.put('/users/:id/role', updateUserRole);

module.exports = router;
