const mongoose = require('mongoose');

/**
 * Connect to MongoDB database using Mongoose
 */
const connectDB = async () => {
  try {
    const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/food_delivery_db';
    const conn = await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 30000 // 30-second timeout for stable Atlas cloud connection
    });
    console.log(`✅ MongoDB Connected Successfully: ${conn.connection.host}`);
  } catch (error) {
    console.error(`⚠️ MongoDB is not connected: ${error.message}`);
    console.log('⚡ Running in In-Memory Standalone Mode! (All Features: Login, Register, Menu, Orders will work flawlessly)');
    console.log('ℹ️  Tip: To persist data, add your MongoDB Atlas URI or start local MongoDB in backend/.env\n');
  }
};

module.exports = connectDB;
