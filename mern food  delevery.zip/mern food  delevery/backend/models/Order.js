const mongoose = require('mongoose');

// Mongoose Schema for Orders
const orderItemSchema = new mongoose.Schema(
  {
    foodId: {
      type: mongoose.Schema.Types.Mixed,
      ref: 'Food',
      default: null
    },
    name: {
      type: String,
      required: true
    },
    price: {
      type: Number,
      required: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 1
    },
    image: {
      type: String
    }
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      required: true
    },
    user: {
      type: mongoose.Schema.Types.Mixed,
      ref: 'User',
      default: null
    },
    customer: {
      name: {
        type: String,
        required: [true, 'Customer name is required']
      },
      email: {
        type: String,
        required: [true, 'Customer email is required']
      },
      phone: {
        type: String,
        required: [true, 'Customer phone number is required']
      },
      address: {
        type: String,
        required: [true, 'Delivery address is required']
      },
      city: {
        type: String,
        default: 'New Delhi'
      },
      pincode: {
        type: String,
        default: '110001'
      }
    },
    items: [orderItemSchema],
    totalAmount: {
      type: Number,
      required: [true, 'Order total amount is required']
    },
    paymentMethod: {
      type: String,
      default: 'UPI / Online'
    },
    status: {
      type: String,
      enum: ['Order Placed', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'],
      default: 'Order Placed'
    }
  },
  {
    timestamps: true
  }
);

const Order = mongoose.model('Order', orderSchema);

module.exports = Order;
