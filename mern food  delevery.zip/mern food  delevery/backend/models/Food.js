const mongoose = require('mongoose');

// Mongoose Schema for Food Items
const foodSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide a food name'],
      trim: true
    },
    description: {
      type: String,
      required: [true, 'Please provide a food description']
    },
    price: {
      type: Number,
      required: [true, 'Please provide a price in INR'],
      min: [0, 'Price cannot be negative']
    },
    image: {
      type: String,
      required: [true, 'Please provide an image URL']
    },
    category: {
      type: String,
      required: [true, 'Please specify a category'],
      trim: true
    },
    rating: {
      type: Number,
      default: 4.5,
      min: 1,
      max: 5
    },
    isVeg: {
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true
  }
);

const Food = mongoose.model('Food', foodSchema);

module.exports = Food;
